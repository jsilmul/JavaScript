var booCookie = false; //Si se permiten cookies cambia a true

function validateEmail() {

    var email = document.getElementById("formMail");

    // Expresión regular
    var validarEmail = /^\w+([.-_+]?\w+)*@\w+([.-]?\w+)*(\.\w{2,10})+$/;


    if (validarEmail.test(email.value)) {
        //alert('Valido');
        document.getElementById("valMail").innerHTML = "Válido";
        document.getElementById("valMail").style = "color:green";
        document.cookie = "mail=" + email.value;
        return true;
    } else {
        //alert('No valido');
        document.getElementById("valMail").innerHTML = "No válido";
        document.getElementById("valMail").style = "color:red";
        return false;
    }
}

function validatePassword() {

    var contra = document.getElementById("formContrasena");

    var validarContra = /^(?=\w*\d)(?=\w*[A-Z])(?=\w*[a-z])\S{8,16}$/;

    if (validarContra.test(contra.value)) {
        document.getElementById("valContrasena").innerHTML = "Válido";
        document.getElementById("valContrasena").style = "color:green";
        document.cookie = "contraseña=" + contra.value;
        return true;
    } else {
        document.getElementById("valContrasena").innerHTML = "La contraseña debe tener al entre 8 y 16 caracteres, al menos un dígito, al menos una minúscula y al menos una mayúscula.";
        document.getElementById("valContrasena").style = "color:red";
        return false;
    }
}

function validateMailPassword() {

    var comprobacion = validateEmail() && validatePassword() && booCookie;

    if (comprobacion) {

        document.location.href = "pantallaRegistro.html";

    } else if (!booCookie) {
        alert("Se deben aceptar las cookies.")
        document.getElementById('ventana-cookies').className = 'div-cookies';
    } else {
        alert("Alguno de los campos no es correcto.");
    }
}

function accionSi() {
    document.getElementById('ventana-cookies').className = 'ventana-oculta';
    booCookie = true;
    localStorage.setItem("Cookie",booCookie);
}

function accionNo() {
    document.getElementById('ventana-cookies').className = 'ventana-oculta';
    booCookie=false;
    localStorage.setItem("Cookie",booCookie);
}

function compruebaCookie(){
    if (localStorage.getItem("Cookie")){
        accionSi();
    }
}

//---------------------FORMULARIO DE REGISTRO-------------------------


function validateName(x) {
    var expresion = /^([A-ZÁÉÍÓÚ]{1}[a-zñáéíóú]+[\s]*)+$/;
    if (!expresion.test(x)) {
        alert("Debe empezar con mayúscula.");
        return false;
    } else {
        return true;
    }
}



function validatePassword2(contra2) {
    var validarContra2 = /^(?=\w*\d)(?=\w*[A-Z])(?=\w*[a-z])\S{8,16}$/;
    if (!validarContra2.test(contra2)) {
        alert("La contraseña debe tener al entre 8 y 16 caracteres, al menos un dígito, al menos una minúscula y al menos una mayúscula.");
        return false;
    } else {
        return true;
    }
}

function confirmaPassword() {
    var contra1 = document.getElementById("regContrasena").value;
    var contra2 = document.getElementById("regConfirmaContrasena").value;
    if (!(contra1 == contra2)) {
        alert("Las contraseñas no coinciden.");
        return false;
    } else {
        return true;
    }
}

function validateEmail2() {

    var email2 = document.getElementById("regEmail").value;

    // Expresión regular
    var validarEmail = /^\w+([.-_+]?\w+)*@\w+([.-]?\w+)*(\.\w{2,10})+$/;

    if (!validarEmail.test(email2)) {
        alert('Formato de correo electronico incorrecto.');
        return false;
    } else{
        return true;
    }
}


/*
var idIdioma = document.getElementById('idIdioma');
idIdioma.addEventListener('change',
    function () {
        alert("f")
        var selectedOption = this.options[idIdioma.selectedIndex];
        console.log(selectedOption.value + ': ' + selectedOption.text);
    });*/

function registrar() {

    
    var nombre = document.getElementById("regNombre").value;
    var apellido = document.getElementById("regApellidos").value;
    var contrasena = document.getElementById("regContrasena").value;
    var email3 = document.getElementById("regEmail").value;

    var genero;
    var radios = document.getElementsByName('genero');
    for (var radio of radios) {
        if (radio.checked) {
            genero = radio.value;
        }
    }

    
    var isChecked = document.getElementById('regConsentimiento').checked;
    //var idIdioma = document.getElementsById("regIdioma");
    //var idioma = idIdioma.options[idIdioma.selectedIndex].value;
    var registroCorrecto = confirmaPassword() && validatePassword2(contrasena) && validateEmail2() && validateName(nombre) && validateName(apellido) && isChecked;


    if (localStorage.getItem("Cookie")&&registroCorrecto){
    localStorage.setItem("Nombre", nombre);
    localStorage.setItem("Apellido", apellido);
    localStorage.setItem("Contrasena", contrasena);
    localStorage.setItem("Email", email3);
    localStorage.setItem("Genero", genero);
    //localStorage.setItem("Idioma", selectedOption.value);
    document.location.href = "pantallaDatosUsuario.html";
    } else if (!registroCorrecto){
        alert("Falta algún campo.");
    } else {
        alert("Debe aceptar las cookies.")
        document.location.reload();
    }
    
}

function getCookie(name) {
    let matches = document.cookie.match(new RegExp(
        "(?:^|; )" + name.replace(/([\.$?*|{}\(\)\[\]\\\/\+^])/g, '\\$1') + "=([^;]*)"
    ));
    return matches ? decodeURIComponent(matches[1]) : undefined;
}

function recuperaCookies() {
    document.getElementById("cooNombre").innerHTML = localStorage.getItem("Nombre");
    document.getElementById("cooApellido").innerHTML = localStorage.getItem("Apellido");
    document.getElementById("cooContrasena").innerHTML = localStorage.getItem("Contrasena");
    document.getElementById("cooEmail").innerHTML = localStorage.getItem("Email");
    document.getElementById("cooGenero").innerHTML = localStorage.getItem("Genero");
    document.getElementById("cooIdioma").innerHTML = localStorage.getItem("Idioma");
}

function cierraSesion(){
    localStorage.clear();
    document.location.href="pantallaBienvenida.html"