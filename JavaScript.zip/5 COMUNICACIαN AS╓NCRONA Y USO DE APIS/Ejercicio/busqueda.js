const apiKey = "15b695963b04df80f390d2cab908e0b9";
const urlBase = "https://api.themoviedb.org/3";

const busqueda = document.getElementById("searchInput");
const resultados = document.getElementById("searchResults");

busqueda.addEventListener("input", () => {
  const query = busqueda.value;
  if (query.length >= 3) {
    // Hacer una solicitud a la API de TMDb
    fetch(`${urlBase}/search/movie?api_key=${apiKey}&query=${query}&language=es-ES`)
      .then((response) => response.json())
      .then((data) => {
        // Actualizar la lista de resultados
        resultados.innerHTML = "";
        data.results.forEach((pelicula) => {
          const title = pelicula.title;
          const id = pelicula.id;
          const li = document.createElement("li");
          li.textContent = title;
          li.addEventListener("click", () => {
            // Mostrar la tarjeta de información
            const url = `https://api.themoviedb.org/3/movie/${id}?api_key=${apiKey}&language=es-ES`;
            fetch(url)
              .then((response) => response.json())
              .then((data) => {
                const tarjeta = document.getElementById("card");
                tarjeta.innerHTML = "";
                tarjeta.appendChild(createMovieCard(data));
                resultados.innerHTML = "";
              });
          });
          resultados.appendChild(li);
        });
      });
  } else {
    resultados.innerHTML = "";
  }
});

function createMovieCard(movie) {
  const card = document.createElement("div");
  card.classList.add("card", "bg-dark", "text-white", "mb-3");

  const row = document.createElement("div");
  row.classList.add("row", "no-gutters");
  card.appendChild(row);

  const imageContainer = document.createElement("div");
  imageContainer.classList.add("col-md-4");
  row.appendChild(imageContainer);

  const image = document.createElement("img");
  image.src = `https://image.tmdb.org/t/p/w500${movie.poster_path}`;
  image.alt = movie.title;
  image.classList.add("card-img");
  imageContainer.appendChild(image);

  const bodyContainer = document.createElement("div");
  bodyContainer.classList.add("col-md-8");
  row.appendChild(bodyContainer);

  const title = document.createElement("h5");
  title.classList.add("card-title");
  title.textContent = movie.title;
  bodyContainer.appendChild(title);

  const favoriteButton = document.createElement("img");
  favoriteButton.setAttribute("data-id", movie.id);
  favoriteButton.src = "img/estrellaborde.png";
  let listFavorites = getFavorites();

  for (const favorite of listFavorites) {
    if (favorite == movie.id) {
      favoriteButton.src = "img/estrella.png";
      break;
    }
  }
  favoriteButton.className = "col-md-1 img-fluid rounded-end";

  if (
    window.location.pathname.includes("Busqueda.html")
  ) {
    favoriteButton.addEventListener("click", (evento) => {
      let id = evento.target.getAttribute("data-id");
      if (favoriteButton.src.includes("estrellaborde")) {
        favoriteButton.src = "img/estrella.png";
        addToFavorites(id);
      } else {
        favoriteButton.src = "img/estrellaborde.png";
        deleteFromFavorites(id);
      }
    });
  }

  bodyContainer.appendChild(favoriteButton);

  const overview = document.createElement("p");
  overview.classList.add("card-text");
  overview.textContent = movie.overview;
  bodyContainer.appendChild(overview);

  const language = document.createElement("h6");
  language.classList.add("card-text");
  language.textContent = "Lenguaje original";
  bodyContainer.appendChild(language);

  const language2 = document.createElement("p");
  language2.classList.add("card-text");
  language2.textContent = movie.original_language;
  bodyContainer.appendChild(language2);

  const date = document.createElement("h6");
  date.classList.add("card-text");
  date.textContent = "Fecha de estreno";
  bodyContainer.appendChild(date);

  const date2 = document.createElement("p");
  date2.classList.add("card-text");
  date2.textContent = movie.release_date;
  bodyContainer.appendChild(date2);

  const points = document.createElement("h6");
  points.classList.add("card-text");
  points.textContent = "Puntuación media";
  bodyContainer.appendChild(points);

  const points2 = document.createElement("p");
  points2.classList.add("card-text");
  points2.textContent = movie.vote_average;
  bodyContainer.appendChild(points2);

  return card;
}
