//1 Crear un nuevo panel de puntuaciones más altas

//Crea una función createScoreBoard que cree un objeto que sirva como tablón de
//puntuaciones altas. Las claves de este objeto serán los nombres de los jugadores y los
//valores serán sus puntuaciones. En su inicialización, deberá contener un primer registro
//con el jugador “GOAT” y 100000 como puntuación.


function createScoreBoard(){
    let scoreBoard = {"GOAT": 11000000};
    return scoreBoard;
}


//2 Añadir jugadores a un panel de puntuaciones

//Para añadir un jugador a la tabla de puntuaciones, define la función addPlayer que
//aceptará tres parámetros:
// ● El primer parámetro es un objeto scoreBoard existente.
// ● El segundo parámetro es el nombre de un jugador en forma de cadena.
// ● El tercer parámetro es la puntuación en forma de número.
//La función devolverá el mismo scoreBoard introducido tras agregar el nuevo jugador.

function addPlayer(scoreBoard, playerName, score) {
    scoreBoard[playerName] = score;
    return scoreBoard;
  }

//3 Eliminar jugadores de un panel de puntuaciones

//Si los jugadores violan las reglas del salón recreativo, son eliminados manualmente de la
//tabla de puntuaciones. Define una función removePlayer que recibe dos parámetros:
// ● El primer parámetro es un objeto scoreBoard existente.
// ● El segundo parámetro es el nombre del jugador en forma de cadena de texto.
//Esta función debe eliminar del panel la entrada para el jugador dado y devolver el panel
//después. Si el jugador no estaba en el tablero en primer lugar, no debería pasarle nada al
//tablero. Se devolverá tal cual.

function removePlayer(scoreBoard, playerName){
    delete scoreBoard[playerName];
    return scoreBoard;
}


//4 Aumentar la puntuación de un jugador
//Si un jugador termina otra partida en el salón recreativo, se añadirá una cierta cantidad de
//puntos a la puntuación anterior en el tablero. Implementa updateScore, que toma tres
//parámetros:
// ● El primer parámetro es un objeto scoreBoard existente.
// ● El segundo parámetro es el nombre del jugador cuya puntuación debe ser
//incrementada en forma de cadena de texto.
// ● El tercer parámetro es la puntuación que se desea añadir a la puntuación máxima
//almacenada.
//La función debe devolver el tablero de puntuaciones después de que se haya realizado la
//actualización.

function updateScore(scoreBoard, playerName, points) {
    scoreBoard[playerName] += points;
    return scoreBoard;
  }

//5 Aplicar los puntos de bonificación de los lunes
//El salón recreativo mantiene un tablero de puntuación separado los lunes. Al final del día,
//cada jugador de ese tablero obtiene 100 puntos adicionales.
//Implementa la función applyMondayBonus que acepta un tablero de puntuación. La
//función añade los puntos de bonificación para cada jugador que aparece en ese tablero.
//Después, se devuelve el tablero.
function applyMondayBonus(scoreBoard) {
    for(let playerName in scoreBoard) {
      scoreBoard[playerName] += 100;
    }
    return scoreBoard;
  }

//6 Normalizar una puntuación alta
//Los distintos salones recreativos otorgan puntuaciones diferentes. Para encontrar al mejor
//jugador arcade de la ciudad, la puntuación de un jugador debe normalizarse para que las
//puntuaciones de los distintos salones arcade sean comparables.
//Escribe una función normalizeScore. En lugar de dos parámetros, esta función debería
//aceptar un objeto como parámetro. Ese objeto contendrá dos claves:
//- score: cuyo valor es un número que representa la puntuación de un jugador.
//- normalizeFunction: cuyo valor es de tipo function y tiene como cometido, a partir
//de una puntuación recibida como argumento, devolver la puntuación normalizada.
// Tu función normalizeScore debe devolver la puntuación normalizada que se obtiene
//después de aplicar normalizeFunction a la puntuación recibida.
  

function normalize(score) {
    return 2 * score + 10;
}

function normalizeScore(parameters){
    return parameters.normalizefunction(parameters.score);
}


function applyNormalization(scoreBoard, normalizafunctionSelected){
    for(let playerName in scoreBoard){
        scoreBoard.playerName = normalizeScore (score, scoreBoard[playerName], normalizefunction, normalizafunctionSelected)
    }
}

//

function verPuntos(){
    console.log(scoreBoard);
}

    createScoreBoard();
    addPlayer(scoreBoard, 'Juan', 0);
    verPuntos(Object.values(scoreBoard));