class ScoreBoard {
    constructor() {
        this.GOAT = 100000;
    }

    addPlayer(playerName, score) {
        this[playerName] = score;
    }

    removePlayer(playerName) {
        delete this[playerName];
    }

    updateScore(playerName, pointsToAdd) {
        this[playerName] += pointsToAdd;
    }
}

class StatisticalScoreBoard extends ScoreBoard {
    topFive() {
        // We build an array with the users and it's scores because arrays are sortables
        let sortableArray = [];
        for (let user in this) {
            sortableArray.push([user, this[user]]);
        }

        // Sort function
        sortableArray.sort(function (a, b) {
            return b[1] - a[1];
        });

        // Loop for building and object with the first five users
        let result = {}
        for (let i = 0; i < 5 && i < sortableArray.length; i++) {
            result[sortableArray[i][0]] = sortableArray[i][1];
        }

        return result;
    }

    gameStats() {
        let max = 0;
        let min = 999999999;
        let totalPoints = 0;
        let numPlayers = Object.keys(this).length;
        for (let user in this) {
            let points = this[user]
            max = points > max ? points : max;
            min = points < min ? points : min;
            totalPoints += points;
        }
        return { 'numPlayers': numPlayers, 'avgScore': totalPoints / numPlayers, 'highest': max, 'lower': min };
    }
}