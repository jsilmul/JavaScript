function createScoreBoard() {
    return { 'GOAT': 100000 }
}

function addPlayer(scoreBoard, playerName, score) {
    scoreBoard[playerName] = score;
    return scoreBoard;
}

function removePlayer(scoreBoard, playerName) {
    delete scoreBoard[playerName];
    return scoreBoard;
}

function updateScore(scoreBoard, playerName, pointsToAdd) {
    scoreBoard[playerName] += pointsToAdd;
    return scoreBoard;
}

function applyMondayBonus(scoreBoard) {
    for (let playerName in scoreBoard) {
        updateScore(scoreBoard, playerName, 100);
    }
    return scoreBoard;
}

function normalize(score) {
    return 2 * score + 10;
}

function normalizeScore(parameters) {
    return parameters.normalizeFunction(parameters.score);
}

function applyNormalization(scoreBoard, normalizeFunctionSelected) {
    for (let playerName in scoreBoard) {
        scoreBoard[playerName] = normalizeScore({ score: scoreBoard[playerName], normalizeFunction: normalizeFunctionSelected });
    }
    return scoreBoard;
}
