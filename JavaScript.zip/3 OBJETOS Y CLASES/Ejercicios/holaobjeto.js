//Escribe el código, una línea para cada acción:

//1 Crea un objeto user vacío.
//2  Agrega la propiedad name con el valor John.
//3 Agrega la propiedad surname con el valor Smith.
//4 Cambia el valor de name a Pete.
//5 Remueve la propiedad name del objeto.

let user = {};
user.name = "John";
user.surname = "Smith";
user.name = "Pete";
delete user.name;

console.log(user);