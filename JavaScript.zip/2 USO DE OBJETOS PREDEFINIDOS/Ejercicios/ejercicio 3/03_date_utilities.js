function fechas(){
  var fechaMostrada=new Date();
  var fechaActual=new Date();
  var milisegundosActuales=fechaActual.getTime(); //milisegundos que han pasado desde el 1 de Enero de 1970
  var seleccion=document.getElementById("dates").value;
  switch (seleccion){
      case "date_now":
          fechaMostrada=fechaActual;
          break;
      case "date_five_mins_ago":
          fechaMostrada=new Date(milisegundosActuales-5*60000);
          break;
      case "date_next_week":
          fechaMostrada=new Date(milisegundosActuales+7*24*60*60000);
          break;
  }
  const dias = [ 'domingo', 'lunes', 'martes', 'jueves', 'viernes', 'sábado',];
  const meses =[ 'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre']
  let mes =meses[fechaMostrada.getMonth()]
  let dia=dias[fechaMostrada.getDay()]
  document.getElementById("output_p").innerHTML="Hoy es " + dia + ", "+fechaMostrada.getDate()+" de "+ mes+", de " 
  + fechaMostrada.getFullYear() + " y son las " + fechaMostrada.getHours()+":"+fechaMostrada.getMinutes()+":"+fechaMostrada.getSeconds() ;
}