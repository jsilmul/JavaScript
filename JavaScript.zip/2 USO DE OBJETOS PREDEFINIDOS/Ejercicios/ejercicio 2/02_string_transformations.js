function transformar(){
    var texto=document.getElementById('original_text').value;
    if (document.getElementById("upper_case").checked){
        texto=texto.toUpperCase();
    } else if (document.getElementById("lower_case").checked){
        texto=texto.toLowerCase();
    } else if (document.getElementById("capitalize").checked){
        texto=texto.charAt(0).toUpperCase()+texto.slice(1);
    } else if (document.getElementById("camel_case").checked){
        var listaCadenas=texto.split(" ")
        let textoAux="";
        let N=listaCadenas.length;
        for (let i = 0;i<N;i++){
            textoAux=textoAux+listaCadenas[i].charAt(0).toUpperCase()+listaCadenas[i].slice(1);
        }
        texto=textoAux;
    } else if (document.getElementById("mimimi").checked){
        texto=texto.replace(/[aeou]/g,"i");
        texto=texto.replace(/[áéóú]/,"í");
        texto=texto.replace(/[ÁÉÓÚ]/,"Í");
        texto=texto.replace(/[AEOU]/g,"I");
    } else if (document.getElementById("reshulon").checked){
        let longitud=texto.length;
        let textoAux="";
        for (let i = 0;i<=longitud;i=i+2){
            textoAux=textoAux+texto.charAt(i).toUpperCase()+texto.charAt(i+1).toLowerCase();
        }
        texto=textoAux;
    }
    document.getElementById('transformed_text').innerHTML=texto;
}