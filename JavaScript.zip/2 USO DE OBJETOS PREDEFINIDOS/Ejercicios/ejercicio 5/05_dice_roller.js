/**
 * Esta función lanza un cierto número de dados especificados y los muestra.
 * 
 * @param {number} n 
 */
function dados(n){

    let suma=0;
    document.getElementById("dice_1_result").src="";
    document.getElementById("dice_2_result").src="";

    for (i=0;i<n;i++){
        rnd=Math.floor(Math.random()*6)+1;
        suma+=rnd;
        if (i==0){
            document.getElementById("dice_1_result").src="img/D6-" + rnd + ".png"
        } else if (i==1){
            document.getElementById("dice_2_result").src="img/D6-" + rnd + ".png"
        }
    }
    var texto="Se han lanzado " + n + " dados, y se ha obtenido " + suma;
    if (document.getElementById("keep_log").checked){
    document.getElementById('log_area').innerHTML+= texto + "\n" 
    }
}