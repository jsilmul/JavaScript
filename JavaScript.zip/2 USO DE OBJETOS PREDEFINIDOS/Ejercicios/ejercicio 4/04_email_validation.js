function validateEmail(){

	var email = document.getElementById("input_mail");
	
	// Expresión regular
	var validarEmail =  /^\w+([.-_+]?\w+)*@\w+([.-]?\w+)*(\.\w{2,10})+$/;

	
	if( validarEmail.test(email.value) ){
		//alert('Valido');
		document.getElementById("validation_label").innerHTML="Válido";
		document.getElementById("validation_label").style="color:green";
		return true;
	}else{
		//alert('No valido');
		document.getElementById("validation_label").innerHTML="No válido";
		document.getElementById("validation_label").style="color:red";
		return false;
	}
} 